folderify --completions fish | source
